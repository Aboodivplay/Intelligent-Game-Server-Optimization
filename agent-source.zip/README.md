# Minecraft Paper agent

This small plugin measures real host CPU, Java heap usage, TPS, loaded entities and online players. It sends authenticated telemetry every five seconds. It does not predict failures or execute remediation commands.

1. Install Java 17+ and Maven. Paper versions requiring Java 21 must run on Java 21.
2. Run `mvn package` in this folder. Dependencies are downloaded from PaperMC's repository.
3. Copy `target/igso-agent-1.0.0.jar` into your Paper server's `plugins` folder.
4. Start Paper once to generate `plugins/IGSOAgent/config.yml`, then stop it.
5. Register a connection in the website. Download its private `config.yml` and put it in `plugins/IGSOAgent/`.
6. Restart Paper. The website shows live readings only after a valid sample arrives.

Compatibility target: Paper 1.20.1+ API, Minecraft Java only. Forge, Fabric, vanilla and other games are not implemented. Check compatibility on your actual Paper version before relying on it. CPU/TPS overhead and the research latency targets have not been benchmarked.

Game-state collection uses Paper's main-thread scheduler. HTTPS transmission runs asynchronously. Overlapping sends are skipped, requests have timeouts, and failures are logged at most once a minute. Unavailable CPU readings are skipped instead of being presented as a real zero. If telemetry stops for 30 seconds, the website marks the connection offline and hides live details.

The agent key permits telemetry ingestion for one server. Keep it out of Git and public screenshots. Account passwords are never placed on the Minecraft server.
