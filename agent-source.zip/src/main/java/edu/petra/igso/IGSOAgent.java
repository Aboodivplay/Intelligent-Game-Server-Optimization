package edu.petra.igso;

import com.sun.management.OperatingSystemMXBean;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Reads game state on the Minecraft thread and sends HTTPS requests off-thread. */
public final class IGSOAgent extends JavaPlugin {
    private final AtomicBoolean sending = new AtomicBoolean(false);
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private URI endpoint;
    private String serverId;
    private String agentKey;
    private long lastWarning;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            endpoint = URI.create(getConfig().getString("endpoint", ""));
            serverId = getConfig().getString("server-id", "");
            agentKey = getConfig().getString("agent-key", "");
            if (!"https".equals(endpoint.getScheme()) || endpoint.getHost() == null ||
                !serverId.matches("[a-f0-9-]{36}") || !agentKey.matches("[a-f0-9]{64}")) {
                throw new IllegalArgumentException("Missing valid HTTPS endpoint, server ID or agent key.");
            }
        } catch (IllegalArgumentException error) {
            getLogger().warning("Configure IGSOAgent/config.yml with your downloaded connection settings, then restart Paper.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        int seconds = Math.max(5, Math.min(60, getConfig().getInt("interval-seconds", 5)));
        Bukkit.getScheduler().runTaskTimer(this, this::collect, 100L, seconds * 20L);
        getLogger().info("IGSO telemetry enabled. No game-server commands or automatic remediation are executed.");
    }

    private void collect() {
        if (!sending.compareAndSet(false, true)) return;
        try {
            // Bukkit game-state access stays on the main thread.
            int entities = 0;
            for (World world : Bukkit.getWorlds()) entities += world.getEntityCount();
            int players = Bukkit.getOnlinePlayers().size();
            double tps = Math.max(0, Math.min(20, Bukkit.getTPS()[0]));
            Runtime runtime = Runtime.getRuntime();
            long used = (runtime.totalMemory() - runtime.freeMemory()) / 1048576;
            long maximum = runtime.maxMemory() / 1048576;
            double memory = maximum == 0 ? 0 : 100.0 * used / maximum;
            OperatingSystemMXBean system = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
            double cpuLoad = system.getCpuLoad();
            // An unavailable OS reading is not a genuine zero; skip this sample.
            if (!Double.isFinite(cpuLoad) || cpuLoad < 0 || !Double.isFinite(tps)) {
                sending.set(false);
                warnOccasionally("CPU or tick-rate reading unavailable; telemetry sample skipped.");
                return;
            }
            double cpu = Math.min(100, cpuLoad * 100);
            String payload = String.format(Locale.ROOT,
                "{\"serverId\":\"%s\",\"cpu\":%.2f,\"memory\":%.2f,\"tps\":%.2f,\"entities\":%d,\"players\":%d,\"memoryUsedMb\":%d,\"memoryMaxMb\":%d,\"platform\":\"Paper\"}",
                serverId, cpu, memory, tps, entities, players, used, maximum);
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> send(payload));
        } catch (Exception error) {
            sending.set(false);
            warnOccasionally("Could not collect telemetry. Check Paper compatibility.");
        }
    }

    private void send(String payload) {
        try {
            HttpRequest request = HttpRequest.newBuilder(endpoint)
                .timeout(Duration.ofSeconds(8))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + agentKey)
                .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<Void> response = http.send(request, HttpResponse.BodyHandlers.discarding());
            if (response.statusCode() != 201) warnOccasionally("Telemetry rejected with HTTP " + response.statusCode() + ". Check connection settings.");
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
        } catch (Exception error) {
            warnOccasionally("Telemetry backend is unreachable. Retrying at the next sampling interval.");
        } finally {
            sending.set(false);
        }
    }

    private synchronized void warnOccasionally(String message) {
        long now = System.currentTimeMillis();
        if (now - lastWarning > 60000) { lastWarning = now; getLogger().warning(message); }
    }
}
