# Minecraft forecasting data and evaluation

No production model has been trained because no aligned game telemetry dataset has been supplied. The website does not produce simulated predictions.

1. Run the updated Paper agent across representative player loads and healthy sessions.
2. Use Predictions > Label a real incident for the actual time of severe server lag or a server crash. A client startup/mod compatibility crash is not a server failure.
3. Export training data regularly (latest 10,000 samples per export). Merge exports only for the same server, deduplicating timestamps. Retain all incident labels.
4. Review coverage: unknown or missing labels cannot be called healthy automatically. Keep private coordinates and commands out of the dataset.
5. Install NumPy in a local Python environment and run `python ml/train.py minecraft-training.json --healthy-periods-reviewed` only after reviewing healthy coverage.

The script is a deliberately readable logistic baseline. It uses causal recent-window features, a 5-minute forecast target, chronological train/validation/test splits, a 6-minute embargo and training-only normalization. It rejects insufficient or single-class datasets. Validation chooses a conservative alert threshold; a failed gate disables all alerts. The final test set is not used to choose the threshold. Reports include precision, recall, false-positive rate and confusion counts.

This baseline is not the proposed LSTM, is not automatically deployed and is not proof of production accuracy. A model must beat this baseline on independent server incidents, be evaluated per incident (not just correlated five-second windows), then run in shadow mode on new sessions. Review missed failures as well as false alarms. Zero false positives on a finite test cannot guarantee zero future false positives.

The provided Scribd document is a client initialization/class compatibility report, useful for diagnosis but missing the required pre-failure server time series. No copyrighted report text or private system details are copied into the training data.
