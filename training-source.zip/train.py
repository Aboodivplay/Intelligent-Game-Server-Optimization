"""Readable first forecasting baseline. Uses only reviewed, real server exports.
This is a logistic baseline, not the proposed LSTM and not a deployed model.
Usage: python ml/train.py minecraft-training.json --healthy-periods-reviewed
"""
import argparse
import json
from datetime import datetime
from pathlib import Path
import numpy as np

SIGNALS = ["cpu", "memory", "tps", "entities"]

def seconds(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()

def windows(data):
    rows = sorted(data["samples"], key=lambda row: row["timestamp"])
    events = sorted(seconds(event["occurred_at"]) for event in data["incidents"])
    times = np.array([seconds(row["timestamp"]) for row in rows])
    values = np.array([[float(row[key]) for key in SIGNALS] for row in rows])
    if not np.isfinite(values).all() or len(set(times)) != len(times):
        raise ValueError("Samples must have unique times and finite measurements.")
    features, labels, anchors = [], [], []
    for index in range(11, len(rows)):
        # A causal 60-second window. Never bridge outages or plugin restarts.
        start = index - 11
        if times[index] - times[start] > 70 or np.diff(times[start:index+1]).max() > 10:
            continue
        if times[index] + 300 > times[-1]:
            continue  # Future outcome is not observed yet.
        if any(times[index]-300 <= event <= times[index] for event in events):
            continue  # Exclude failure/recovery periods from healthy examples.
        block = values[start:index+1]
        features.append(np.concatenate([block[-1], block.mean(0), block.max(0), block[-1]-block[0]]))
        labels.append(int(any(0 < event-times[index] <= 300 for event in events)))
        anchors.append(times[index])
    return np.array(features), np.array(labels), np.array(anchors)

def metrics(labels, scores, threshold):
    predicted = scores >= threshold
    tp = int(((labels == 1) & predicted).sum())
    fp = int(((labels == 0) & predicted).sum())
    fn = int(((labels == 1) & ~predicted).sum())
    tn = int(((labels == 0) & ~predicted).sum())
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, precision=tp/max(1,tp+fp), recall=tp/max(1,tp+fn), false_positive_rate=fp/max(1,fp+tn))

def train(data, reviewed):
    if not reviewed:
        raise ValueError("Review healthy coverage and label all known incidents before treating unlabeled periods as healthy.")
    x,y,t = windows(data)
    if len(x) < 2000 or len(data["incidents"]) < 10:
        raise ValueError("Collect at least 2000 valid windows and 10 labeled server incidents across multiple sessions. More independent incidents are strongly recommended.")
    # Time-ordered split with a 6-minute embargo: windows and future labels do not cross boundaries.
    first,second = t[int(len(t)*.6)],t[int(len(t)*.8)]
    masks = [t < first-360, (t > first+360)&(t < second-360), t > second+360]
    if any(sum(mask)<100 or len(np.unique(y[mask]))<2 for mask in masks):
        raise ValueError("Train, validation and test periods must each contain failures and healthy samples after the embargo.")
    mean,std = x[masks[0]].mean(0),x[masks[0]].std(0)
    std[std<1e-6]=1
    z=(x-mean)/std
    a,b=z[masks[0]],y[masks[0]]
    weights=np.zeros(a.shape[1]);bias=0.0
    # Fixed training budget; test data never chooses epochs or model parameters.
    for _ in range(1500):
        score=1/(1+np.exp(-np.clip(a@weights+bias,-30,30)))
        error=score-b
        weights-=.03*(a.T@error/len(a)+.001*weights)
        bias-=.03*error.mean()
    score=1/(1+np.exp(-np.clip(z@weights+bias,-30,30)))
    choices=[]
    for threshold in np.arange(.5,1,.01):
        result=metrics(y[masks[1]],score[masks[1]],threshold)
        if result["precision"]>=.95 and result["false_positive_rate"]<=.01 and result["tp"]>=20:
            choices.append((result["recall"],float(threshold)))
    threshold=max(choices)[1] if choices else 1.01  # No alerts if the validation gate fails.
    test=metrics(y[masks[2]],score[masks[2]],threshold)
    report=dict(model="logistic temporal baseline", horizon_seconds=300, threshold=threshold,
        validation_gate_passed=bool(choices), held_out_test=test, split="chronological 60/20/20 with 360-second embargo",
        deployment_ready=False, note="Sample metrics are correlated within incidents. Require incident-level review and a prospective shadow trial. Zero observed false positives is not a future guarantee.")
    artifact=dict(signals=SIGNALS,feature_order="last,mean,max,delta over 12 five-second samples",mean=mean.tolist(),scale=std.tolist(),weights=weights.tolist(),bias=float(bias),threshold=threshold,report=report)
    return artifact

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset");parser.add_argument("--healthy-periods-reviewed",action="store_true")
    parser.add_argument("--output",default="ml/baseline-review.json")
    args=parser.parse_args()
    try:
        artifact=train(json.loads(Path(args.dataset).read_text()),args.healthy_periods_reviewed)
        Path(args.output).write_text(json.dumps(artifact,indent=2))
        print(json.dumps(artifact["report"],indent=2))
    except (ValueError,KeyError) as error:
        raise SystemExit("Not ready for training: "+str(error))
